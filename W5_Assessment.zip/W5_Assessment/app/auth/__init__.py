from flask import Blueprint
from app.auth import views

auth = Blueprint('auth', __name__)


