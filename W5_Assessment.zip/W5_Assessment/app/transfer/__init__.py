from flask import Blueprint
from app.transfer import views

transfer = Blueprint('transfer', __name__)


