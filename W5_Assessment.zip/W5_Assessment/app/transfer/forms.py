from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, SubmitField
from wtforms.validators import DataRequired, Length, ValidationError

class TransferForm(FlaskForm):
    receiver_account = StringField('Receiver Account', validators=[DataRequired(), Length(min=10, max=20)])
    amount = FloatField('Amount', validators=[DataRequired()])
    submit = SubmitField('Initiate Transfer')

    def validate_amount(self, amount):
        if amount.data <= 0:
            raise ValidationError('Amount must be greater than zero.')
