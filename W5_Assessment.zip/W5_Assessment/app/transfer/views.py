from flask import render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app import app, db
from app.models import Transaction
from app.transfer.forms import TransferForm

@app.route('/initiate_transfer', methods=['GET', 'POST'])
@login_required
def initiate_transfer():
    form = TransferForm()
    if form.validate_on_submit():
        if current_user.balance < form.amount.data:
            flash('Insufficient balance.')
            return redirect(url_for('initiate_transfer'))

        transaction = Transaction(sender_id=current_user.id, receiver_account=form.receiver_account.data, amount=form.amount.data)
        db.session.add(transaction)
        db.session.commit()
        flash('Transfer initiated successfully!')
        return redirect(url_for('transfer_status', transaction_id=transaction.id))
    return render_template('transfer/initiate_transfer.html', title='Initiate Transfer', form=form)

@app.route('/transfer_status/<transaction_id>')
@login_required
def transfer_status(transaction_id):
    transaction = Transaction.query.get(transaction_id)
    if transaction.sender_id != current_user.id:
        flash('Unauthorized access to transfer status.')
        return redirect(url_for('index'))
    return render_template('transfer/transfer_status.html', title='Transfer Status', transaction=transaction)
