import os
# app = Flask(__name__)
# app.secret_key = 'cdab9878676d9fcd4e43b95b750c4d446d237e0f89ffb065c804318821d7757d'
class Config:
    SECRET_KEY = os.environ.get('cdab9878676d9fcd4e43b95b750c4d446d237e0f89ffb065c804318821d7757d')
    SQLALCHEMY_DATABASE_URI = os.environ.get('sqlite:///intbank.db') or \
        'sqlite:///' + os.path.join(os.path.abspath(os.path.dirname(__file__)), 'intbank.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
