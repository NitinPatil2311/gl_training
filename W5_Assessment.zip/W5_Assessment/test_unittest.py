import unittest
from app import app, db
from app.models import User, Transaction

class TestAuthentication(unittest.TestCase):

    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:intbank:'
        self.app = app.test_client()
        db.create_all()

    def tearDown(self):
        db.session.remove()
        db.drop_all()

    def test_login(self):
        response = self.app.post('/login', data=dict(
            username='Nitin',
            password='Nitin@123'
        ), follow_redirects=True)
        self.assertIn(b'Login Successful!', response.data)

    def test_register(self):
        response = self.app.post('/register', data=dict(
            username='Nitin',
            password='Nitin@123',
            password2='Nitin@123'
        ), follow_redirects=True)
        self.assertIn(b'Congratulations, you are now a registered user!', response.data)

class TestTransactionProcessing(unittest.TestCase):

    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:intbank:'
        self.app = app.test_client()
        db.create_all()

    def tearDown(self):
        db.session.remove()
        db.drop_all()

    def test_transaction_processing(self):
        user = User(username='Pranay')
        db.session.add(user)
        db.session.commit()

        response = self.app.post('/initiate_transfer', data=dict(
            receiver_account='abcd1234',
            amount=100
        ))
        self.assertIn(b'Transfer initiated successfully!', response.data)

if __name__ == '__main__':
    unittest.main()

